package com.shieldstream.tv.details

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.shieldstream.tv.strings.R as StringsR
import com.shieldstream.tv.strings.localizedCode
import com.shieldstream.tv.strings.localizedStringResource
import com.shieldstream.tv.ui.component.AppIcons

/**
 * Botones de la ficha en móvil: "Reproducir/Continuar" a todo el ancho y, debajo, Fuentes / Tráiler / Más
 * repartidos por igual. Misma lógica que la TV (mismos callbacks); solo cambia la forma de pulsar.
 */
@Composable
internal fun MobileActionButtons(
    state: DetailsUiState.Content,
    interactive: Boolean,
    onPlay: () -> Unit,
    onPlayFromStart: () -> Unit,
    onOpenSources: () -> Unit,
    onOpenActions: () -> Unit,
    onTrailer: (() -> Unit)?,
) {
    val progress = state.mainProgress
    val resumable = progress?.isResumable == true
    val episodeCode = state.selectedEpisode?.takeIf { state.isSeries }?.let { " ${it.localizedCode()}" }.orEmpty()
    val playLabel = when {
        state.pendingPlay -> localizedStringResource(StringsR.string.details_preparing)
        resumable -> localizedStringResource(StringsR.string.details_resume_episode, episodeCode)
        else -> localizedStringResource(StringsR.string.details_play_episode, episodeCode)
    }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(
            onClick = onPlay,
            enabled = interactive,
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) {
            Icon(AppIcons.Play, contentDescription = null, modifier = Modifier.size(22.dp))
            Text("  $playLabel", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (resumable && !state.pendingPlay) {
            SecondaryButton(
                text = localizedStringResource(StringsR.string.details_from_the_beginning),
                icon = null,
                enabled = interactive,
                onClick = onPlayFromStart,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            SecondaryButton(
                text = localizedStringResource(StringsR.string.details_sources),
                icon = AppIcons.List,
                enabled = interactive,
                onClick = onOpenSources,
                modifier = Modifier.weight(1f),
            )
            if (onTrailer != null) {
                SecondaryButton(
                    text = localizedStringResource(StringsR.string.details_trailer),
                    icon = AppIcons.Movie,
                    enabled = interactive,
                    onClick = onTrailer,
                    modifier = Modifier.weight(1f),
                )
            }
            if (detailsMoreVisible(state.pendingPlay)) {
                SecondaryButton(
                    text = localizedStringResource(StringsR.string.details_more),
                    icon = null,
                    enabled = interactive,
                    onClick = onOpenActions,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun SecondaryButton(
    text: String,
    icon: ImageVector?,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
        modifier = modifier.height(48.dp),
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            androidx.compose.foundation.layout.Spacer(Modifier.size(6.dp))
        }
        Text(text, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
