package com.shieldstream.tv.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.shieldstream.tv.model.CatalogItem
import com.shieldstream.tv.model.CatalogRow
import com.shieldstream.tv.model.ContinueInfo
import com.shieldstream.tv.model.Episode
import com.shieldstream.tv.model.RowStyle
import com.shieldstream.tv.strings.R as StringsR
import com.shieldstream.tv.strings.localizedCode
import com.shieldstream.tv.strings.localizedStringResource
import com.shieldstream.tv.ui.component.CatalogPosterCard
import com.shieldstream.tv.ui.component.ContinueCard
import com.shieldstream.tv.ui.component.LabeledPosterCard
import com.shieldstream.tv.ui.component.MobileEdge
import com.shieldstream.tv.ui.component.MobileRowSpacing
import com.shieldstream.tv.ui.component.NewEpisodeCard
import com.shieldstream.tv.ui.component.formatEpisodeDate
import com.shieldstream.tv.ui.component.mobilePosterWidth

private data class MobileItemMenu(val item: CatalogItem)
private data class MobileUpNextMenu(val item: CatalogItem, val episode: Episode)

/**
 * Lista vertical de filas de pósteres para móvil (Inicio y Categorías). Cada fila es un `LazyRow`; la pulsación larga
 * abre los mismos menús que en la TV. [header] se pinta antes de las filas (portada, chips…).
 */
@Composable
internal fun MobileRowsList(
    rows: List<CatalogRow>,
    onItemClick: (CatalogItem) -> Unit,
    modifier: Modifier = Modifier,
    onContinueClick: ((CatalogItem, ContinueInfo) -> Unit)? = null,
    onNewEpisodeClick: ((CatalogItem, Episode) -> Unit)? = null,
    onUpNextClick: ((CatalogItem, Episode) -> Unit)? = null,
    onRemoveContinue: (CatalogItem) -> Unit = {},
    onRemoveMyList: (CatalogItem) -> Unit = {},
    onMarkUpNextWatched: ((CatalogItem, Episode) -> Unit)? = null,
    onRemoveUpNext: ((CatalogItem, Episode) -> Unit)? = null,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    header: LazyListScope.() -> Unit = {},
) {
    var continueMenu by remember { mutableStateOf<MobileItemMenu?>(null) }
    var myListMenu by remember { mutableStateOf<MobileItemMenu?>(null) }
    var upNextMenu by remember { mutableStateOf<MobileUpNextMenu?>(null) }

    LazyColumn(modifier, contentPadding = contentPadding) {
        header()
        items(rows, key = { it.id }) { row ->
            MobileRow(
                row = row,
                onItemClick = onItemClick,
                onContinueClick = onContinueClick,
                onNewEpisodeClick = onNewEpisodeClick,
                onUpNextClick = onUpNextClick,
                onContinueMenu = { continueMenu = MobileItemMenu(it) },
                onMyListMenu = { myListMenu = MobileItemMenu(it) },
                onUpNextMenu = { item, episode -> upNextMenu = MobileUpNextMenu(item, episode) },
            )
        }
        item { Spacer(Modifier.height(24.dp)) }
    }

    continueMenu?.let { menu ->
        ContinueActions(
            item = menu.item,
            onDetails = { continueMenu = null; onItemClick(menu.item) },
            onRemove = { onRemoveContinue(menu.item); continueMenu = null },
            onCancel = { continueMenu = null },
        )
    }
    myListMenu?.let { menu ->
        MyListActions(
            item = menu.item,
            onDetails = { myListMenu = null; onItemClick(menu.item) },
            onRemove = { onRemoveMyList(menu.item); myListMenu = null },
            onCancel = { myListMenu = null },
        )
    }
    upNextMenu?.let { menu ->
        UpNextActions(
            item = menu.item,
            onDetails = { upNextMenu = null; onItemClick(menu.item) },
            onMarkWatched = { onMarkUpNextWatched?.invoke(menu.item, menu.episode); upNextMenu = null },
            onRemove = { onRemoveUpNext?.invoke(menu.item, menu.episode); upNextMenu = null },
            onCancel = { upNextMenu = null },
        )
    }
}

@Composable
private fun MobileRow(
    row: CatalogRow,
    onItemClick: (CatalogItem) -> Unit,
    onContinueClick: ((CatalogItem, ContinueInfo) -> Unit)?,
    onNewEpisodeClick: ((CatalogItem, Episode) -> Unit)?,
    onUpNextClick: ((CatalogItem, Episode) -> Unit)?,
    onContinueMenu: (CatalogItem) -> Unit,
    onMyListMenu: (CatalogItem) -> Unit,
    onUpNextMenu: (CatalogItem, Episode) -> Unit,
) {
    val width = mobilePosterWidth()
    Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
        Text(
            text = row.title,
            color = Color.White,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = MobileEdge),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = MobileEdge, vertical = 10.dp),
            horizontalArrangement = MobileRowSpacing,
        ) {
            itemsIndexed(row.items, key = { index, it -> "${it.key}#$index" }) { _, item ->
                when (row.style) {
                    RowStyle.POSTER, RowStyle.TOP10 -> CatalogPosterCard(
                        item = item,
                        onClick = { onItemClick(item) },
                        width = width,
                        newEpisodeCount = row.newEpisodeCounts[item.key] ?: 0,
                    )
                    RowStyle.MY_LIST -> CatalogPosterCard(
                        item = item,
                        onClick = { onItemClick(item) },
                        onLongClick = { onMyListMenu(item) },
                        width = width,
                        newEpisodeCount = row.newEpisodeCounts[item.key] ?: 0,
                    )
                    RowStyle.CONTINUE -> {
                        val info = row.progress[item.key]
                        ContinueCard(
                            item = item,
                            fraction = info?.fraction ?: 0f,
                            label = info?.label.orEmpty(),
                            onClick = {
                                if (info == null || onContinueClick == null) onItemClick(item) else onContinueClick(item, info)
                            },
                            onLongClick = { onContinueMenu(item) },
                            newEpisodeCount = row.newEpisodeCounts[item.key] ?: 0,
                            width = width,
                        )
                    }
                    RowStyle.NEW_EPISODES -> {
                        val episode = row.newEpisodes[item.key]
                        val label = episode?.let {
                            listOf(it.localizedCode(), formatEpisodeDate(it.airDate)).filter { p -> p.isNotEmpty() }.joinToString(" · ")
                        }.orEmpty()
                        NewEpisodeCard(
                            item = item,
                            label = label,
                            count = row.newEpisodeCounts[item.key] ?: 1,
                            width = width,
                            onClick = {
                                if (episode == null || onNewEpisodeClick == null) onItemClick(item) else onNewEpisodeClick(item, episode)
                            },
                        )
                    }
                    RowStyle.UP_NEXT -> {
                        val info = row.upNext[item.key]
                        val episode = info?.episode
                        if (episode == null) {
                            CatalogPosterCard(item = item, onClick = { onItemClick(item) }, width = width)
                        } else {
                            val badge = when (upNextBadge(info)) {
                                UpNextBadge.NEW_SEASON -> localizedStringResource(StringsR.string.home_new_season)
                                UpNextBadge.NEW_EPISODE -> localizedStringResource(StringsR.string.home_new_episode)
                                UpNextBadge.UP_NEXT -> localizedStringResource(StringsR.string.home_up_next)
                            }
                            val episodeLabel = listOf(episode.localizedCode(), episode.title).filter { it.isNotEmpty() }.joinToString(" · ")
                            LabeledPosterCard(
                                item = item,
                                badge = badge,
                                badgeDot = upNextBadge(info) != UpNextBadge.UP_NEXT,
                                label = listOf(episodeLabel, formatEpisodeDate(episode.airDate)).filter { it.isNotEmpty() }.joinToString("\n"),
                                onClick = {
                                    if (onUpNextClick == null) onItemClick(item) else onUpNextClick(item, episode)
                                },
                                onLongClick = { onUpNextMenu(item, episode) },
                                width = width,
                            )
                        }
                    }
                }
            }
        }
    }
}
