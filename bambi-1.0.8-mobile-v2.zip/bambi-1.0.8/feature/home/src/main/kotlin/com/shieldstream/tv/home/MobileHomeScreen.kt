package com.shieldstream.tv.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.shieldstream.tv.domain.EpisodeTarget
import com.shieldstream.tv.model.CatalogItem
import com.shieldstream.tv.model.Category
import com.shieldstream.tv.model.ContinueInfo
import com.shieldstream.tv.model.Episode
import com.shieldstream.tv.model.FeaturedItem
import com.shieldstream.tv.model.HomeFilter
import com.shieldstream.tv.strings.R as StringsR
import com.shieldstream.tv.strings.localizedStringResource
import com.shieldstream.tv.strings.localizedTitle
import com.shieldstream.tv.ui.component.MobileChip
import com.shieldstream.tv.ui.component.MobileEdge
import com.shieldstream.tv.ui.theme.AppColors

/**
 * Inicio táctil: portada deslizable, accesos (Reproduce algo / Sorpréndeme), categorías y filas de pósteres.
 * Usa el mismo [HomeViewModel] que la TV (misma clave, así comparte la precarga).
 */
@Composable
internal fun MobileHomeScreen(
    filter: HomeFilter,
    onItemClick: (CatalogItem) -> Unit,
    onContinueClick: (CatalogItem, ContinueInfo) -> Unit,
    onNewEpisodeClick: (CatalogItem, Episode) -> Unit,
    onUpNextClick: (CatalogItem, Episode) -> Unit,
    onPlaySomething: (CatalogItem, EpisodeTarget?) -> Unit,
    onOpenCategory: (Category) -> Unit,
    onContentReady: () -> Unit = {},
    modifier: Modifier = Modifier,
    viewModel: HomeViewModel = hiltViewModel(key = "home_${filter.name}"),
) {
    LaunchedEffect(filter) { viewModel.load(filter) }
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val hidden by viewModel.hiddenCategories.collectAsStateWithLifecycle()

    when (val s = state) {
        HomeUiState.Loading -> Box(modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            androidx.compose.material3.CircularProgressIndicator(color = Color.White)
        }
        is HomeUiState.Error -> MobileMessage(
            message = s.message,
            actionLabel = localizedStringResource(StringsR.string.home_retry),
            onAction = { viewModel.load(filter, force = true) },
            modifier = modifier,
        )
        is HomeUiState.Content -> {
            LaunchedEffect(Unit) { onContentReady() }
            val categories = remember(filter, hidden) {
                when {
                    viewModel.kidsProfile -> Category.forFilter(filter).filter { it in Category.KIDS_SAFE }
                    else -> Category.forFilter(filter).filter { it.name !in hidden }.ifEmpty { Category.forFilter(filter) }
                }
            }
            val rows = s.rows
            val featured = s.featured
            fun cancelAnd(block: () -> Unit) {
                viewModel.cancelBackgroundPrefetch()
                block()
            }
            MobileRowsList(
                rows = rows,
                modifier = modifier.fillMaxSize().background(Color.Black),
                onItemClick = { cancelAnd { onItemClick(it) } },
                onContinueClick = { item, info -> cancelAnd { onContinueClick(item, info) } },
                onNewEpisodeClick = { item, episode -> cancelAnd { onNewEpisodeClick(item, episode) } },
                onUpNextClick = { item, episode -> cancelAnd { onUpNextClick(item, episode) } },
                onRemoveContinue = viewModel::removeFromContinue,
                onRemoveMyList = viewModel::removeFromMyList,
                onMarkUpNextWatched = viewModel::markUpNextWatched,
                onRemoveUpNext = viewModel::removeUpNext,
            ) {
                if (featured.isNotEmpty()) {
                    item(key = "billboard") {
                        MobileBillboard(
                            featured = featured,
                            onInfo = { cancelAnd { onItemClick(it) } },
                            onPlay = { cancelAnd { onPlaySomething(it, null) } },
                        )
                    }
                }
                item(key = "shortcuts") {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = MobileEdge, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        OutlinedButton(
                            onClick = {
                                when (val pick = playSomethingPick(rows, featured)) {
                                    is PlaySomethingPick.UpNext -> cancelAnd {
                                        onPlaySomething(pick.item, EpisodeTarget(pick.episode.season, pick.episode.number))
                                    }
                                    is PlaySomethingPick.NewEpisode -> cancelAnd {
                                        onPlaySomething(pick.item, EpisodeTarget(pick.episode.season, pick.episode.number))
                                    }
                                    is PlaySomethingPick.Continue -> cancelAnd {
                                        val season = pick.info.season
                                        val episode = pick.info.episode
                                        onPlaySomething(
                                            pick.item,
                                            if (season != null && episode != null) EpisodeTarget(season, episode) else null,
                                        )
                                    }
                                    is PlaySomethingPick.Title -> cancelAnd { onPlaySomething(pick.item, null) }
                                    null -> Unit
                                }
                            },
                            modifier = Modifier.weight(1f).height(48.dp),
                        ) {
                            Text(localizedStringResource(StringsR.string.home_play_something), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        OutlinedButton(
                            onClick = { surprisePick(rows, featured)?.let { cancelAnd { onItemClick(it) } } },
                            modifier = Modifier.weight(1f).height(48.dp),
                        ) {
                            Text(localizedStringResource(StringsR.string.home_surprise_me), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                if (categories.isNotEmpty()) {
                    item(key = "categories") {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = MobileEdge),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            items(categories, key = { it.name }) { category ->
                                MobileChip(text = category.localizedTitle(), selected = false, onClick = { onOpenCategory(category) })
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Portada deslizable de destacados: toque = ficha; botón Reproducir = reproducir ya. Sin animaciones continuas. */
@Composable
private fun MobileBillboard(
    featured: List<FeaturedItem>,
    onInfo: (CatalogItem) -> Unit,
    onPlay: (CatalogItem) -> Unit,
) {
    val widthDp = LocalConfiguration.current.screenWidthDp
    val height = (widthDp * 1.15f).coerceIn(300f, 520f).dp
    val pagerState = rememberPagerState(pageCount = { featured.size })
    Column(Modifier.fillMaxWidth()) {
        HorizontalPager(state = pagerState, modifier = Modifier.fillMaxWidth().height(height)) { page ->
            val f = featured[page]
            val item = f.item
            Box(
                Modifier
                    .fillMaxSize()
                    .clickable { onInfo(item) },
            ) {
                val url = item.posterUrl ?: item.backdropUrl
                if (url != null) {
                    AsyncImage(
                        model = url,
                        contentDescription = item.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(0.4f to Color.Transparent, 1f to Color.Black)),
                )
                Column(
                    Modifier.align(Alignment.BottomStart).padding(horizontal = MobileEdge, vertical = 14.dp),
                ) {
                    Text(
                        text = item.title,
                        color = Color.White,
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = metaLine(item),
                        color = Color(0xFF46D369),
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        maxLines = 1,
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { onPlay(item) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                            modifier = Modifier.height(48.dp),
                        ) {
                            Text(localizedStringResource(StringsR.string.mobile_home_play), fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { onInfo(item) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White.copy(alpha = 0.22f),
                                contentColor = Color.White,
                            ),
                            modifier = Modifier.height(48.dp),
                        ) {
                            Text(localizedStringResource(StringsR.string.home_more_info), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        if (featured.size > 1) {
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.Center,
            ) {
                repeat(featured.size) { index ->
                    Box(
                        Modifier
                            .padding(horizontal = 3.dp)
                            .size(if (index == pagerState.currentPage) 8.dp else 6.dp)
                            .clip(CircleShape)
                            .background(if (index == pagerState.currentPage) AppColors.Accent else Color.White.copy(alpha = 0.35f)),
                    )
                }
            }
        }
    }
}

/** Mensaje centrado con un botón (errores). */
@Composable
internal fun MobileMessage(
    message: String,
    actionLabel: String,
    onAction: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier.fillMaxSize().background(Color.Black).padding(MobileEdge),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(message, color = Color.White, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onAction, modifier = Modifier.height(48.dp)) { Text(actionLabel) }
    }
}
