package com.shieldstream.tv.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shieldstream.tv.model.CatalogItem
import com.shieldstream.tv.strings.R as StringsR
import com.shieldstream.tv.strings.localizedStringResource
import com.shieldstream.tv.ui.component.ActionMenuDialog
import com.shieldstream.tv.ui.component.ActionMenuItem
import com.shieldstream.tv.ui.component.AppIcons
import com.shieldstream.tv.ui.component.LineIcons
import com.shieldstream.tv.ui.component.MobileEdge
import com.shieldstream.tv.ui.component.MobileIconButton
import com.shieldstream.tv.ui.component.PosterCard
import com.shieldstream.tv.ui.component.mobilePosterWidth
import kotlinx.coroutines.delay

/** Buscar en móvil: campo de texto con el teclado del sistema y rejilla de resultados. No pide foco al abrir. */
@Composable
internal fun MobileSearchScreen(
    onItemClick: (CatalogItem) -> Unit,
    viewModel: SearchViewModel,
) {
    val query by viewModel.query.collectAsStateWithLifecycle()
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val notice by viewModel.notice.collectAsStateWithLifecycle()
    var lockedPick by remember { mutableStateOf<CatalogItem?>(null) }
    val focusManager = LocalFocusManager.current
    LaunchedEffect(notice) {
        if (notice != null) {
            delay(3_500)
            viewModel.consumeNotice()
        }
    }
    lockedPick?.let { item ->
        ActionMenuDialog(
            title = item.title,
            onDismiss = { lockedPick = null },
            actions = listOf(
                ActionMenuItem(localizedStringResource(StringsR.string.home_cancel), LineIcons.Close) { lockedPick = null },
                ActionMenuItem(localizedStringResource(StringsR.string.home_ask_an_adult_action), AppIcons.Lock) {
                    viewModel.requestTitle(item)
                    lockedPick = null
                },
            ),
        )
    }

    Column(Modifier.fillMaxSize().background(Color.Black).imePadding()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = MobileEdge, vertical = 8.dp)
                .height(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF1C1C1F))
                .padding(start = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(AppIcons.Search, contentDescription = null, tint = Color.White.copy(alpha = 0.6f), modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                BasicTextField(
                    value = query,
                    onValueChange = { viewModel.setQuery(it.replace("\n", "")) },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.titleMedium.copy(color = Color.White),
                    cursorBrush = SolidColor(Color.White),
                    keyboardOptions = KeyboardOptions(autoCorrectEnabled = false, imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }, onDone = { focusManager.clearFocus() }),
                    modifier = Modifier.fillMaxWidth(),
                )
                if (query.isEmpty()) {
                    Text(
                        text = localizedStringResource(StringsR.string.mobile_search_hint),
                        color = Color.White.copy(alpha = 0.45f),
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            if (query.isNotEmpty()) {
                MobileIconButton(
                    icon = LineIcons.Close,
                    contentDescription = localizedStringResource(StringsR.string.mobile_clear),
                    onClick = viewModel::clear,
                )
            }
        }

        val header = when (val s = state) {
            SearchUiState.Loading -> localizedStringResource(StringsR.string.home_searching)
            is SearchUiState.Suggestions -> localizedStringResource(StringsR.string.home_most_watched_today)
            is SearchUiState.Results -> localizedStringResource(StringsR.string.home_search_results_for, s.query)
            is SearchUiState.Empty -> localizedStringResource(StringsR.string.home_no_results_for, s.query)
            is SearchUiState.Error -> s.message
        }
        Text(
            text = header,
            color = Color.White,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            modifier = Modifier.padding(horizontal = MobileEdge, vertical = 6.dp),
        )
        notice?.let { message ->
            Text(
                text = message,
                color = Color.White,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier
                    .padding(start = MobileEdge, bottom = 6.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = 0.16f))
                    .padding(horizontal = 14.dp, vertical = 6.dp),
            )
        }

        val items = when (val s = state) {
            is SearchUiState.Suggestions -> s.items
            is SearchUiState.Results -> s.items
            else -> emptyList()
        }
        val results = state as? SearchUiState.Results
        val locked = results?.locked.orEmpty()
        val pending = results?.pending.orEmpty()
        val width = mobilePosterWidth()

        LazyVerticalGrid(
            columns = GridCells.Adaptive(width),
            contentPadding = PaddingValues(MobileEdge),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(items, key = { it.key }) { item ->
                PosterCard(item = item, onClick = { onItemClick(item) }, width = width)
            }
            if (locked.isNotEmpty()) {
                item(key = "locked_header", span = { GridItemSpan(maxLineSpan) }) {
                    Column(Modifier.padding(top = 12.dp)) {
                        Text(
                            localizedStringResource(StringsR.string.home_ask_an_adult),
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        )
                        Text(
                            localizedStringResource(StringsR.string.home_ask_an_adult_hint),
                            color = Color.White.copy(alpha = 0.6f),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
                items(locked, key = { "locked_" + it.key }) { item ->
                    val asked = item.key in pending
                    PosterCard(
                        item = item,
                        onClick = { if (!asked) lockedPick = item },
                        width = width,
                        overlay = { LockedOverlay(asked) },
                    )
                }
            }
        }
    }
}
