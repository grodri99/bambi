package com.shieldstream.tv.player

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.shieldstream.tv.strings.R as StringsR
import com.shieldstream.tv.strings.localizedStringResource
import com.shieldstream.tv.ui.component.AppIcons
import com.shieldstream.tv.ui.component.MobileIconButton
import com.shieldstream.tv.ui.component.MobileIcons
import com.shieldstream.tv.ui.theme.AppColors

/**
 * Capa de gestos del reproductor en móvil: un toque muestra/oculta los controles; doble toque en la mitad izquierda
 * o derecha retrocede/adelanta [stepMs]. Va encima del vídeo y debajo de los controles.
 */
@Composable
internal fun MobileGestureLayer(
    onTap: () -> Unit,
    onDoubleTapSide: (forward: Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = { offset -> onDoubleTapSide(offset.x >= size.width / 2f) },
                )
            },
    )
}

/**
 * Controles táctiles del reproductor: arriba atrás/título/audio y subtítulos/bloqueo; en el centro ±10 s y
 * reproducir/pausa; abajo la barra de progreso arrastrable con el tiempo.
 */
@Composable
internal fun MobilePlayerControls(
    title: String,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    onBack: () -> Unit,
    onTogglePlay: () -> Unit,
    onSeekBy: (Long) -> Unit,
    onSeekTo: (Long) -> Unit,
    onOpenTracks: () -> Unit,
    onLock: () -> Unit,
    onInteract: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var dragging by remember { mutableStateOf<Float?>(null) }
    val fraction = dragging ?: seekFraction(positionMs, durationMs) ?: 0f
    val shownMs = if (dragging != null && durationMs > 0) (durationMs * fraction).toLong() else positionMs

    Box(
        modifier
            .fillMaxSize()
            // Sin manejadores de toque: un toque en un hueco pasa a la capa de gestos de debajo y oculta los controles.
            .background(Color.Black.copy(alpha = 0.45f)),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 8.dp, vertical = 4.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                MobileIconButton(
                    icon = MobileIcons.Back,
                    contentDescription = localizedStringResource(StringsR.string.mobile_back),
                    onClick = onBack,
                )
                Text(
                    text = title,
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).padding(horizontal = 4.dp),
                )
                MobileIconButton(
                    icon = MobileIcons.Subtitles,
                    contentDescription = localizedStringResource(StringsR.string.mobile_player_audio_subs),
                    onClick = { onInteract(); onOpenTracks() },
                )
                MobileIconButton(
                    icon = MobileIcons.Lock,
                    contentDescription = localizedStringResource(StringsR.string.mobile_player_lock),
                    onClick = onLock,
                )
            }

            Row(
                Modifier.weight(1f).fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                MobileIconButton(
                    icon = MobileIcons.Replay,
                    contentDescription = localizedStringResource(StringsR.string.mobile_seek_back),
                    onClick = { onInteract(); onSeekBy(-SEEK_STEP_MS) },
                    size = 64.dp,
                    iconSize = 36.dp,
                )
                Spacer(Modifier.width(24.dp))
                MobileIconButton(
                    icon = if (isPlaying) AppIcons.Pause else AppIcons.Play,
                    contentDescription = if (isPlaying) {
                        localizedStringResource(StringsR.string.player_pause)
                    } else {
                        localizedStringResource(StringsR.string.player_play)
                    },
                    onClick = onTogglePlay,
                    size = 80.dp,
                    iconSize = 52.dp,
                )
                Spacer(Modifier.width(24.dp))
                MobileIconButton(
                    icon = MobileIcons.Replay,
                    contentDescription = localizedStringResource(StringsR.string.mobile_seek_forward),
                    onClick = { onInteract(); onSeekBy(SEEK_STEP_MS) },
                    modifier = Modifier.graphicsLayer { scaleX = -1f },
                    size = 64.dp,
                    iconSize = 36.dp,
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp)) {
                Text(formatTime(shownMs), color = Color.White, style = MaterialTheme.typography.labelLarge)
                Slider(
                    value = fraction,
                    onValueChange = {
                        dragging = it
                        onInteract()
                    },
                    onValueChangeFinished = {
                        val target = dragging
                        dragging = null
                        if (target != null && durationMs > 0) onSeekTo((durationMs * target).toLong())
                    },
                    enabled = durationMs > 0,
                    colors = SliderDefaults.colors(
                        thumbColor = AppColors.Accent,
                        activeTrackColor = AppColors.Accent,
                        inactiveTrackColor = Color.White.copy(alpha = 0.3f),
                        disabledThumbColor = Color.White.copy(alpha = 0.4f),
                        disabledActiveTrackColor = Color.White.copy(alpha = 0.3f),
                        disabledInactiveTrackColor = Color.White.copy(alpha = 0.2f),
                    ),
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                )
                Text(
                    text = if (durationMs > 0) "-" + formatTime((durationMs - shownMs).coerceAtLeast(0L)) else "",
                    color = Color.White,
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        }
    }
}

/** Con los controles bloqueados solo se ve un botón para desbloquear (aparece al tocar la pantalla). */
@Composable
internal fun MobileUnlockHint(onUnlock: () -> Unit, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing), contentAlignment = Alignment.Center) {
        OutlinedButton(
            onClick = onUnlock,
            modifier = Modifier.background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(50)),
        ) {
            Icon(MobileIcons.Lock, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(localizedStringResource(StringsR.string.mobile_player_unlock), color = Color.White)
        }
    }
}

/** Ajuste de sincronía de subtítulos con botones táctiles (en la TV se hace con las flechas del mando). */
@Composable
internal fun MobileSubtitleSyncBar(
    detail: String,
    onAdjust: (Long) -> Unit,
    onAuto: () -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(top = 8.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.Black.copy(alpha = 0.78f))
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (detail.isNotBlank()) {
            Text(detail, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.size(6.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            for ((label, delta) in listOf("-1 s" to -1_000L, "-0.1" to -100L)) {
                OutlinedButton(onClick = { onAdjust(delta) }) { Text(label, color = Color.White) }
            }
            Button(
                onClick = onAuto,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
            ) { Text("Auto") }
            for ((label, delta) in listOf("+0.1" to 100L, "+1 s" to 1_000L)) {
                OutlinedButton(onClick = { onAdjust(delta) }) { Text(label, color = Color.White) }
            }
            OutlinedButton(onClick = onDone) { Text(localizedStringResource(StringsR.string.mobile_player_done), color = Color.White) }
        }
    }
}

internal const val SEEK_STEP_MS = 10_000L
