package com.shieldstream.tv.player

import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import com.shieldstream.tv.domain.NextEpisode
import com.shieldstream.tv.domain.ProfileRepository
import com.shieldstream.tv.domain.ResolveState
import com.shieldstream.tv.domain.ResolveStreamUseCase
import com.shieldstream.tv.domain.SelectedContentHolder
import com.shieldstream.tv.domain.SettingsRepository
import com.shieldstream.tv.domain.SkipSegmentsRepository
import com.shieldstream.tv.domain.SubtitleRepository
import com.shieldstream.tv.domain.TraktRepository
import com.shieldstream.tv.domain.WatchProgressRepository
import com.shieldstream.tv.media.Media3Factory
import com.shieldstream.tv.media.PlaybackPolicyProvider
import com.shieldstream.tv.model.CatalogItem
import com.shieldstream.tv.model.DeviceOptimization
import com.shieldstream.tv.model.HdrType
import com.shieldstream.tv.model.MediaType
import com.shieldstream.tv.model.PlaybackMedia
import com.shieldstream.tv.model.PlaybackPolicy
import com.shieldstream.tv.model.Profile
import com.shieldstream.tv.model.Quality
import com.shieldstream.tv.model.StreamSource
import com.shieldstream.tv.model.SubtitleAppearance
import com.shieldstream.tv.model.SubtitleColor
import com.shieldstream.tv.model.SubtitlePreference
import com.shieldstream.tv.strings.Texts
import io.mockk.coVerify
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import org.junit.rules.TestWatcher
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.yield
import kotlinx.coroutines.test.setMain
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.Description
import org.junit.runners.model.Statement

@OptIn(ExperimentalCoroutinesApi::class)
class PlayerViewModelTest {

    @get:Rule
    val mainDispatcher = MainDispatcherRule()

    @Test
    fun `player creation does not finish after lifecycle stops`() = runBlocking {
        val allowSettingsRead = CompletableDeferred<Unit>()
        val players = FakePlayers(Tracks.EMPTY)
        val viewModel = fixture(
            players = players,
            bufferSecondsFlow = flow {
                allowSettingsRead.await()
                emit(40)
            },
            subtitlePreference = SubtitlePreference.OFF,
        ).viewModel
        viewModel.start()
        assertNull(viewModel.player.value)

        viewModel.onStop()
        allowSettingsRead.complete(Unit)
        yield()

        assertNull(viewModel.player.value)
        viewModel.onStop()
    }

    @Test
    fun `embedded subtitle preference is reapplied after player recreation`() = runBlocking {
        val players = FakePlayers(spanishTextTracks())
        val viewModel = fixture(
            players = players,
            bufferSecondsFlow = flowOf(40),
            subtitlePreference = SubtitlePreference.SPANISH,
        ).viewModel
        viewModel.start()
        yield()
        players.listener(0).onPlaybackStateChanged(Player.STATE_READY)
        assertTrue(players.parameters[0].overrides.isNotEmpty())

        viewModel.onStop()
        viewModel.onStart()
        yield()
        players.listener(1).onPlaybackStateChanged(Player.STATE_READY)

        assertTrue(players.parameters[1].overrides.isNotEmpty())
        viewModel.onStop()
    }

    @Test
    fun `stopping playback saves the selected source with watch progress`() = runBlocking {
        val players = FakePlayers(Tracks.EMPTY)
        val fixture = fixture(players, flowOf(40), SubtitlePreference.OFF)
        fixture.viewModel.start()
        yield()
        every { players.player(0).duration } returns 120_000L
        every { players.player(0).currentPosition } returns 45_000L

        fixture.viewModel.onStop()

        verify(exactly = 1) {
            fixture.watchProgress.save("movie:1", 45_000L, 120_000L, "source")
        }
    }

    @Test
    fun `reaching the end marks the item watched even without a reported duration`() = runBlocking {
        val players = FakePlayers(Tracks.EMPTY)
        val fixture = fixture(players, flowOf(40), SubtitlePreference.OFF)
        fixture.viewModel.start()
        yield()

        players.listener(0).onPlaybackStateChanged(Player.STATE_ENDED)

        verify(exactly = 1) { fixture.watchProgress.save("movie:1", 1L, 1L, "source") }
    }

    @Test
    fun `reaching the end marks the item watched with the known duration`() = runBlocking {
        val players = FakePlayers(Tracks.EMPTY)
        val fixture = fixture(players, flowOf(40), SubtitlePreference.OFF)
        fixture.viewModel.start()
        yield()
        every { players.player(0).duration } returns 120_000L

        players.listener(0).onPlaybackStateChanged(Player.STATE_ENDED)

        verify(exactly = 1) { fixture.watchProgress.save("movie:1", 120_000L, 120_000L, "source") }
    }

    @Test
    fun `changing speed with Dolby audio switches to PCM without recreating the player`() = runBlocking {
        val players = FakePlayers(Tracks.EMPTY)
        val fixture = fixture(players, flowOf(40), SubtitlePreference.OFF)
        fixture.viewModel.start()
        yield()
        every { players.player(0).audioFormat } returns
            Format.Builder().setSampleMimeType(MimeTypes.AUDIO_E_AC3).build()

        fixture.viewModel.cyclePlaybackSpeed()
        yield()

        verify(exactly = 0) { players.player(0).release() }
        verify { players.player(0).setPlaybackSpeed(1.25f) }
        // La pista de audio se desactiva (y poco después se reactiva) para montar el decodificador PCM.
        assertTrue(C.TRACK_TYPE_AUDIO in players.parameters[0].disabledTrackTypes)
        fixture.viewModel.onStop()
    }

    @Test
    fun `changing speed with plain audio only sets the speed`() = runBlocking {
        val players = FakePlayers(Tracks.EMPTY)
        val fixture = fixture(players, flowOf(40), SubtitlePreference.OFF)
        fixture.viewModel.start()
        yield()
        every { players.player(0).audioFormat } returns
            Format.Builder().setSampleMimeType(MimeTypes.AUDIO_AAC).build()

        fixture.viewModel.cyclePlaybackSpeed()
        yield()

        verify { players.player(0).setPlaybackSpeed(1.25f) }
        verify(exactly = 0) { players.player(0).release() }
        fixture.viewModel.onStop()
    }

    @Test
    fun `sleep timer cycles from off to end of episode and back`() = runBlocking {
        val fixture = fixture(FakePlayers(Tracks.EMPTY), flowOf(40), SubtitlePreference.OFF)
        val viewModel = fixture.viewModel

        assertEquals(SleepTimer.Off, viewModel.sleepTimer.value)
        listOf(15, 30, 45, 60, 90).forEach { minutes ->
            viewModel.cycleSleepTimer()
            assertEquals(SleepTimer.Minutes(minutes), viewModel.sleepTimer.value)
        }
        viewModel.cycleSleepTimer()
        assertEquals(SleepTimer.EndOfEpisode, viewModel.sleepTimer.value)
        viewModel.cycleSleepTimer()
        assertEquals(SleepTimer.Off, viewModel.sleepTimer.value)

        viewModel.onStop()
    }

    @Test
    fun `end of episode sleep timer stops instead of playing the next episode`() = runBlocking {
        val players = FakePlayers(Tracks.EMPTY)
        val fixture = fixture(
            players = players,
            bufferSecondsFlow = flowOf(40),
            subtitlePreference = SubtitlePreference.OFF,
            next = NextEpisode("show", season = 1, episode = 2, label = "S1E2"),
        )
        fixture.viewModel.start()
        yield()
        repeat(6) { fixture.viewModel.cycleSleepTimer() }
        assertEquals(SleepTimer.EndOfEpisode, fixture.viewModel.sleepTimer.value)

        players.listener(0).onPlaybackStateChanged(Player.STATE_ENDED)

        assertEquals(SleepTimer.Off, fixture.viewModel.sleepTimer.value)
        verify(exactly = 1) { players.player(0).pause() }
        assertNull(fixture.holder.consumeNextRequest())
        fixture.viewModel.onStop()
    }

    @Test
    fun `subtitle appearance updates immediately and persists normalized values`() = runBlocking {
        val fixture = fixture(FakePlayers(Tracks.EMPTY), flowOf(40), SubtitlePreference.OFF)
        val requested = SubtitleAppearance(
            sizePercent = 999,
            verticalPositionPercent = -5,
            textColor = SubtitleColor.YELLOW,
        )
        val expected = requested.normalized()

        fixture.viewModel.setSubtitleAppearance(requested)

        assertEquals(expected, fixture.viewModel.subtitleAppearance.value)
        coVerify(exactly = 1) { fixture.settings.setSubtitleAppearance(expected) }
    }

    private fun fixture(
        players: FakePlayers,
        bufferSecondsFlow: Flow<Int>,
        subtitlePreference: SubtitlePreference,
        next: NextEpisode? = null,
    ): Fixture {
        val policy = PlaybackPolicy.automatic(512L * 1024 * 1024)
        val media3Factory = mockk<Media3Factory>()
        every { media3Factory.createPlayer(any(), any()) } answers { players.create() }
        every { media3Factory.dataSourceFactory } returns mockk()
        val playbackPolicies = mockk<PlaybackPolicyProvider> {
            every { automatic() } returns policy
            every { resolve(any(), any(), any()) } returns policy
        }
        val resolve = mockk<ResolveStreamUseCase>()
        every { resolve.invoke(any<StreamSource>()) } returns flowOf<ResolveState>(
            ResolveState.Ready("https://example.test/video"),
        )
        val settings = mockk<SettingsRepository>(relaxed = true) {
            every { deviceOptimization } returns flowOf(DeviceOptimization.CUSTOM)
            every { this@mockk.maxBufferSeconds } returns bufferSecondsFlow
            every { seekThumbnails } returns flowOf(false)
            every { autoNextEpisode } returns flowOf(true)
            every { tracksPanelCard } returns flowOf(false)
            every { autoSkipIntro } returns flowOf(false)
        }
        val profile = Profile(
            id = "test",
            name = "Test",
            avatar = 0,
            spanishFirst = false,
            spanishOnlySources = false,
            subtitlePreference = subtitlePreference,
            matchContentFrameRate = false,
        )
        val profiles = mockk<ProfileRepository> {
            every { active } returns MutableStateFlow(profile)
        }
        val item = CatalogItem(
            id = "1",
            imdbId = "tt1",
            type = MediaType.MOVIE,
            title = "Movie",
            overview = "",
            posterUrl = null,
            backdropUrl = null,
            year = 2020,
            rating = null,
        )
        val holder = SelectedContentHolder().apply {
            selectItem(item)
            playQueue(
                sources = listOf(source()),
                label = "Movie",
                progressKey = "movie:1",
                media = PlaybackMedia(MediaType.MOVIE, "tt1", "Movie", "Movie", 2020),
                next = next,
            )
        }
        val watchProgress = mockk<WatchProgressRepository>(relaxed = true)
        return Fixture(
            settings = settings,
            watchProgress = watchProgress,
            holder = holder,
            media3Factory = media3Factory,
            viewModel = PlayerViewModel(
                media3Factory = media3Factory,
                playbackPolicies = playbackPolicies,
                resolveStreamUseCase = resolve,
                settings = settings,
                profiles = profiles,
                holder = holder,
                watchProgress = watchProgress,
                subtitles = mockk<SubtitleRepository>(relaxed = true),
                trakt = mockk<TraktRepository>(relaxed = true),
                skipSegmentsRepository = mockk<SkipSegmentsRepository>(relaxed = true),
                trackMemory = mockk(relaxed = true),
                texts = mockk<Texts>(relaxed = true),
            ),
        )
    }

    private fun source() = StreamSource(
        id = "source",
        title = "Source",
        infoHash = "hash",
        fileIdx = null,
        magnet = "",
        quality = Quality.FHD_1080,
        hdrType = HdrType.SDR,
        sizeBytes = 1_000,
        seeders = 1,
        isCached = true,
        directUrl = "https://example.test/video",
    )

    private fun spanishTextTracks(): Tracks {
        val format = Format.Builder()
            .setId("spanish-subtitles")
            .setLanguage("es")
            .setSampleMimeType(MimeTypes.APPLICATION_SUBRIP)
            .build()
        val group = Tracks.Group(
            TrackGroup("subtitles", format),
            false,
            intArrayOf(C.FORMAT_HANDLED),
            booleanArrayOf(false),
        )
        return Tracks(listOf(group))
    }

    private data class Fixture(
        val viewModel: PlayerViewModel,
        val settings: SettingsRepository,
        val watchProgress: WatchProgressRepository,
        val holder: SelectedContentHolder,
        val media3Factory: Media3Factory,
    )

    private class FakePlayers(private val tracks: Tracks) {
        val parameters = mutableListOf<TrackSelectionParameters>()
        private val listeners = mutableListOf<Player.Listener?>()
        private val instances = mutableListOf<ExoPlayer>()

        fun create(): ExoPlayer {
            val player = mockk<ExoPlayer>(relaxed = true)
            instances += player
            var selection = TrackSelectionParameters.DEFAULT
            parameters += selection
            listeners += null
            val index = parameters.lastIndex
            val listener = slot<Player.Listener>()
            every { player.trackSelectionParameters } answers { selection }
            every { player.trackSelectionParameters = any() } answers {
                selection = firstArg()
                parameters[index] = selection
            }
            every { player.currentTracks } returns tracks
            every { player.playbackState } returns Player.STATE_READY
            every { player.duration } returns C.TIME_UNSET
            every { player.currentPosition } returns 0L
            every { player.addListener(capture(listener)) } answers {
                listeners[index] = listener.captured
            }
            return player
        }

        fun listener(index: Int): Player.Listener {
            assertNotNull(listeners[index])
            return listeners[index]!!
        }

        fun player(index: Int): ExoPlayer = instances[index]
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class MainDispatcherRule : TestWatcher() {
    val dispatcher = UnconfinedTestDispatcher()

    override fun apply(base: Statement, description: Description): Statement =
        object : Statement() {
            override fun evaluate() {
                Dispatchers.setMain(dispatcher)
                try {
                    base.evaluate()
                } finally {
                    Dispatchers.resetMain()
                }
            }
        }
}
