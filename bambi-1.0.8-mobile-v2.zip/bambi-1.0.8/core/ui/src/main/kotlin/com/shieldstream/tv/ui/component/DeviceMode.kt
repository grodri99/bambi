package com.shieldstream.tv.ui.component

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * `true` si la app corre en un Android TV / box (mando a distancia). En móviles y tabletas es `false` y se usa la
 * interfaz táctil.
 */
fun isTelevisionDevice(context: Context): Boolean {
    val uiMode = context.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
    return uiMode?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
}

/** Móvil o tableta en vertical (o ventana estrecha). */
@Composable
fun isPortraitLayout(): Boolean {
    val c = LocalConfiguration.current
    return c.screenHeightDp >= c.screenWidthDp
}

/** Ancho de una tarjeta de póster en las filas del móvil: unos 3 pósteres y un trozo del siguiente a la vista. */
@Composable
fun mobilePosterWidth(): Dp {
    val widthDp = LocalConfiguration.current.screenWidthDp
    return remember(widthDp) { ((widthDp - MobileEdge.value * 2) / 3.3f).coerceIn(96f, 170f).dp }
}

/** Margen lateral estándar de las pantallas de móvil. */
val MobileEdge: Dp = 16.dp
